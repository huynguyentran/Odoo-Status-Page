# odoo-status-page-us-internship
US internship's project to manage website status using Odoo
